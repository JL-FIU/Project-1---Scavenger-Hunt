//
//  TaskDetailView.swift
//  Project 1
//
//  Created by Julian Lesesne on 9/13/26.
//

import SwiftUI
import UIKit
import MapKit
import CoreLocation

struct TaskDetailView: View {
    
    @Binding var task: Task
    
    @State private var showingPhotoPicker = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                
                Text(task.title)
                    .font(.title)
                    .fontWeight(.bold)
                
                Text(task.description)
                    .font(.body)
                
                if let image = task.image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .clipShape(
                            RoundedRectangle(cornerRadius: 12)
                        )
                }
                
                if let location = task.location {
                    Map {
                        Marker(
                            task.title,
                            coordinate: location
                        )
                    }
                    .frame(height: 300)
                    .clipShape(
                        RoundedRectangle(cornerRadius: 12)
                    )
                }
                
                Button {
                    showingPhotoPicker = true
                } label: {
                    HStack {
                        Image(systemName: "photo")
                        Text("Attach Photo")
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundStyle(.white)
                    .clipShape(
                        RoundedRectangle(cornerRadius: 10)
                    )
                }
                
                if task.isCompleted {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                        
                        Text("Task Completed")
                            .fontWeight(.semibold)
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Task")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showingPhotoPicker) {
            PhotoPicker(
                image: $task.image,
                location: $task.location
            )
        }
        .onChange(of: task.image) { _, newImage in
            if newImage != nil {
                task.isCompleted = true
            }
        }
    }
}

#Preview {
    TaskDetailView(
        task: .constant(
            Task(
                title: "Your favorite local restaurant",
                description: "Take a photo of your favorite local restaurant."
            )
        )
    )
}
