//
//  TaskDetailView.swift
//  Project 1
//
//  Created by Julian Lesesne on 9/13/26.
//

import SwiftUI
import UIKit
import MapKit
import CoreLocation

struct TaskDetailView: View {
    
    @Binding var task: Task
    
    @State private var showingPhotoOptions = false
    @State private var showingPhotoPicker = false
    @State private var showingCamera = false
    
    @State private var pendingImage: UIImage?
    @State private var pendingLocation: CLLocationCoordinate2D?
    
    @State private var showingSubmitConfirmation = false
    @State private var showingCameraUnavailable = false
    
    var body: some View {
        ScrollView {
            
            VStack(alignment: .leading, spacing: 20) {
                
                Text(task.title)
                    .font(.title)
                    .fontWeight(.bold)
                
                Text(task.description)
                    .font(.body)
                
                // Show the photo that has already been submitted.
                if let image = task.image {
                    
                    Text("Submitted Photo")
                        .font(.headline)
                    
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .clipShape(
                            RoundedRectangle(cornerRadius: 12)
                        )
                }
                
                // Show a newly selected photo before submission.
                if let image = pendingImage {
                    
                    Text("Photo Ready to Submit")
                        .font(.headline)
                    
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity)
                        .clipShape(
                            RoundedRectangle(cornerRadius: 12)
                        )
                    
                    Button {
                        submitPhoto()
                    } label: {
                        HStack {
                            Image(systemName: "checkmark.circle.fill")
                            Text("Submit Photo")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .foregroundStyle(.white)
                        .clipShape(
                            RoundedRectangle(cornerRadius: 10)
                        )
                    }
                }
                
                // Display the map for the submitted photo.
                if let location = task.location {
                    
                    Text("Photo Location")
                        .font(.headline)
                    
                    Map {
                        Marker(
                            task.title,
                            coordinate: location
                        )
                    }
                    .frame(height: 300)
                    .clipShape(
                        RoundedRectangle(cornerRadius: 12)
                    )
                }
                
                // Button used to choose between gallery and camera.
                if !task.isCompleted {
                    
                    Button {
                        showingPhotoOptions = true
                    } label: {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                            Text("Attach Photo")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundStyle(.white)
                        .clipShape(
                            RoundedRectangle(cornerRadius: 10)
                        )
                    }
                }
                
                // Completion indicator.
                if task.isCompleted {
                    
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                        
                        Text("Task Completed")
                            .fontWeight(.semibold)
                    }
                    .padding(.top, 5)
                }
            }
            .padding()
        }
        .navigationTitle("Task")
        .navigationBarTitleDisplayMode(.inline)
        
        // Photo options.
        .confirmationDialog(
            "Add Photo",
            isPresented: $showingPhotoOptions,
            titleVisibility: .visible
        ) {
            
            Button("Choose from Gallery") {
                showingPhotoPicker = true
            }
            
            Button("Take Photo") {
                
                if UIImagePickerController.isSourceTypeAvailable(.camera) {
                    showingCamera = true
                } else {
                    showingCameraUnavailable = true
                }
            }
            
            Button("Cancel", role: .cancel) {
                // Do nothing.
            }
        }
        
        // Gallery picker.
        .sheet(isPresented: $showingPhotoPicker) {
            PhotoPicker(
                image: $pendingImage,
                location: $pendingLocation
            )
        }
        
        // Camera picker.
        .sheet(isPresented: $showingCamera) {
            CameraPicker(
                image: $pendingImage,
                location: $pendingLocation
            )
        }
        
        // Submission confirmation.
        .alert(
            "Photo Submitted",
            isPresented: $showingSubmitConfirmation
        ) {
            Button("OK", role: .cancel) {
            }
        } message: {
            Text("Your task has been marked as complete.")
        }
        
        // Camera availability warning.
        .alert(
            "Camera Unavailable",
            isPresented: $showingCameraUnavailable
        ) {
            Button("OK", role: .cancel) {
            }
        } message: {
            Text("The camera is not available on this device. Try using an iPhone or choose a photo from your gallery.")
        }
    }
    
    private func submitPhoto() {
        
        guard let image = pendingImage else {
            return
        }
        
        task.image = image
        task.location = pendingLocation
        task.isCompleted = true
        
        pendingImage = nil
        pendingLocation = nil
        
        showingSubmitConfirmation = true
    }
}

#Preview {
    TaskDetailView(
        task: .constant(
            Task(
                title: "Your favorite local restaurant",
                description: "Take a photo of your favorite local restaurant."
            )
        )
    )
}
