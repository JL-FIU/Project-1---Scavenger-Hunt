//
//  PhotoPicker.swift
//  Project 1
//
//  Created by Julian Lesesne on 9/13/26.
//

import SwiftUI
import PhotosUI
import Photos
import CoreLocation
import UIKit

struct PhotoPicker: UIViewControllerRepresentable {
    
    @Binding var image: UIImage?
    @Binding var location: CLLocationCoordinate2D?
    
    @Environment(\.dismiss) private var dismiss
    
    func makeUIViewController(
        context: Context
    ) -> PHPickerViewController {
        
        var configuration = PHPickerConfiguration(
            photoLibrary: .shared()
        )
        
        configuration.filter = .images
        configuration.selectionLimit = 1
        
        let picker = PHPickerViewController(
            configuration: configuration
        )
        
        picker.delegate = context.coordinator
        
        return picker
    }
    
    func updateUIViewController(
        _ uiViewController: PHPickerViewController,
        context: Context
    ) {
        // No updates are required.
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        
        let parent: PhotoPicker
        
        init(_ parent: PhotoPicker) {
            self.parent = parent
        }
        
        func picker(
            _ picker: PHPickerViewController,
            didFinishPicking results: [PHPickerResult]
        ) {
            
            guard let result = results.first else {
                parent.dismiss()
                return
            }
            
            // Get the photo's location.
            if let assetIdentifier = result.assetIdentifier {
                
                let assets = PHAsset.fetchAssets(
                    withLocalIdentifiers: [assetIdentifier],
                    options: nil
                )
                
                if let asset = assets.firstObject {
                    parent.location = asset.location?.coordinate
                }
            }
            
            // Load the selected photo.
            result.itemProvider.loadObject(
                ofClass: UIImage.self
            ) { object, error in
                
                if let image = object as? UIImage {
                    
                    DispatchQueue.main.async {
                        self.parent.image = image
                        self.parent.dismiss()
                    }
                    
                } else {
                    
                    DispatchQueue.main.async {
                        self.parent.dismiss()
                    }
                }
            }
        }
    }
}
