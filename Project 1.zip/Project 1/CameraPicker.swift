//
//  CameraPicker.swift
//  Project 1
//
//  Created by Julian Lesesne on 9/14/26.
//

import SwiftUI
import UIKit
import CoreLocation

struct CameraPicker: UIViewControllerRepresentable {
    
    @Binding var image: UIImage?
    @Binding var location: CLLocationCoordinate2D?
    
    @Environment(\.dismiss) private var dismiss
    
    func makeUIViewController(
        context: Context
    ) -> UIImagePickerController {
        
        let picker = UIImagePickerController()
        
        picker.sourceType = .camera
        picker.allowsEditing = false
        picker.delegate = context.coordinator
        
        context.coordinator.startLocationUpdates()
        
        return picker
    }
    
    func updateUIViewController(
        _ uiViewController: UIImagePickerController,
        context: Context
    ) {
        // No updates are required.
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject,
                       UIImagePickerControllerDelegate,
                       UINavigationControllerDelegate,
                       CLLocationManagerDelegate {
        
        let parent: CameraPicker
        
        private let locationManager = CLLocationManager()
        
        init(_ parent: CameraPicker) {
            self.parent = parent
            super.init()
            
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
        }
        
        func startLocationUpdates() {
            
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        }
        
        func imagePickerController(
            _ picker: UIImagePickerController,
            didFinishPickingMediaWithInfo info: [
                UIImagePickerController.InfoKey : Any
            ]
        ) {
            
            if let selectedImage = info[
                .originalImage
            ] as? UIImage {
                
                parent.image = selectedImage
                
                if let currentLocation = locationManager.location {
                    parent.location = currentLocation.coordinate
                }
            }
            
            locationManager.stopUpdatingLocation()
            parent.dismiss()
        }
        
        func imagePickerControllerDidCancel(
            _ picker: UIImagePickerController
        ) {
            
            locationManager.stopUpdatingLocation()
            parent.dismiss()
        }
        
        func locationManager(
            _ manager: CLLocationManager,
            didChangeAuthorization status: CLAuthorizationStatus
        ) {
            
            if status == .authorizedWhenInUse ||
                status == .authorizedAlways {
                
                manager.startUpdatingLocation()
            }
        }
    }
}
