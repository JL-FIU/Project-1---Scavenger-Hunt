//
//  ContentView.swift
//  Project 1
//
//  Created by Julian Lesesne on 9/13/26.
//

import SwiftUI

struct ContentView: View {
    
    @State private var tasks = [
        Task(
            title: "Your favorite local restaurant",
            description: "Take a photo of your favorite local restaurant."
        ),
        Task(
            title: "Your favorite local cafe",
            description: "Take a photo of your favorite local cafe."
        ),
        Task(
            title: "Your go-to brunch place",
            description: "Take a photo of your go-to brunch place."
        ),
        Task(
            title: "Your favorite hiking spot",
            description: "Take a photo of your favorite hiking spot."
        )
    ]
    
    var body: some View {
        NavigationStack {
            List {
                ForEach($tasks) { $task in
                    
                    NavigationLink {
                        TaskDetailView(task: $task)
                    } label: {
                        
                        HStack {
                            
                            VStack(alignment: .leading, spacing: 5) {
                                
                                Text(task.title)
                                    .font(.headline)
                                
                                Text(task.description)
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                            
                            Spacer()
                            
                            if task.isCompleted {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.green)
                                    .font(.title2)
                            } else {
                                Image(systemName: "circle")
                                    .foregroundStyle(.gray)
                                    .font(.title2)
                            }
                        }
                        .padding(.vertical, 5)
                    }
                }
            }
            .navigationTitle("Photo Scavenger Hunt")
        }
    }
}

#Preview {
    ContentView()
}
