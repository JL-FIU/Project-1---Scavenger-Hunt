//
//  Task.swift
//  Project 1
//
//  Created by Julian Lesesne on 9/13/26.
//

import Foundation
import UIKit
import CoreLocation

struct Task: Identifiable {
    
    let id = UUID()
    
    let title: String
    let description: String
    
    var isCompleted: Bool = false
    
    var image: UIImage?
    
    var location: CLLocationCoordinate2D?
}
